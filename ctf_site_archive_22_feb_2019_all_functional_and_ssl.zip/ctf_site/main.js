var blacklist = ['todo: implement'];
var SUBMIT_DELAY = 2*60*1000; // 2 minutes between incorrect submissions

const domain = 'www.exr0n.com' // todo: required: on the server computer the cert files must be set up.
const port = 1337; // obtw: deprecated
const dont_log = ['/favicon.ico', '/watermark', '/submit', '/flagdata', '/create_account', '/userdata/null'];


const express = require('express'); // dependant
const nodemailer = require('nodemailer'); // dependant

const fs = require('fs');
const crypto = require('crypto'); // used to generate tokens

const func = require('./func.js');
var USERDATA = require('./data.json');
var FLAG_DATA = func.recalculate_flag_var(USERDATA);

const path = __dirname + '/';

const app = express();

app.get('/0ac85ebdd65881c00f75b4f9ec4a02e4c5e08fe10d751b8bc9837925f6b5be8f194e3c2608443f333cc50973482e6b06fc9e885118d6f6b17dd9144b26688224a9a40db15e59e0476a4c0f7ed82fee2bcd013597cfe20e2bb446d5465d7353fca6a001d1147b49eea28ec098f132c2a7c7e31a2c9766804b6a11916caad0a529acb7151e1d32326ee0fc2be05b8edeae6d98b2bc2179dbb6bc12d1d6fc64a3d4bfb5d1e9a4610b7e90de70d387f9372d0770822d3339ff2b4345ba8bf3a11f6b2c78644135065967a66a2aa8b0b6e58bbeb5b1c369b251376db888d9a365350ce139be0864724abe2b6ff2f0e74f74dbe8977cf3a576c726030e7e0082988', (req, res) => {
  console.log('\n\n\n\nINSANITY ALERT\n'+`${Date()}\nstopping now`);
  res.cookie('secretsaus', 'itzrainintakoz');
  res.redirect('/');
  process.exit(9001);
})

app.use((req, res) => { // todo: remove this
  if (req.headers.cookie && req.headers.cookie.includes('secretsaus=itzrainintakoz')) {
    req.next();
  } else {
    res.end('The CT24bb event has not started yet!', 403)
  }
})

// forward all to https secure
app.use((req, res) => {
  if(!req.secure) {
    return res.redirect(['https://', req.get('Host'), req.url].join(''));
  }
  req.next();
});

// LOG EVERYTHING
app.use((req, res) => {
  // todo: make a thing that tracks how many hits i get, how popular i am, etc
  req.url = decodeURIComponent(req.url); // decode the url encoding things, like %5D

  // parse ?key=data&key=data etc
  if (req.url.includes('?')) {
    req.uri = {};
    for (let pair of req.url.slice(16).split('&')) req.uri[pair.split('=')[0]] = pair.split('=')[1];
  }

  if (!dont_log.includes(req.url)) {
    func.log(
`
  ${Date()}:
  ${req.method} ${req.protocol}://${req.get('Host')}${req.url}
  from: ${req.ip}
  using: ${req.headers['user-agent']}
  secure: ${req.secure}
`)
  } else {
    func.log(req.method+' '+req.url);
  }
  req.next();
});

/** site access **/
// homepage
app.get('/', (req, res) => res.sendFile(path + 'pages/index.html'));
// faq
app.get('/faq', (req, res) => res.sendFile(path + 'pages/faq.html'));

// create account
app.get('/create_account', (req, res) => {
  if (req.url.includes('?')) {
    /*
    let formdata = {};
    for (let pair of req.url.slice(16).split('&')) formdata[pair.split('=')[0]] = pair.split('=')[1];
    */
    console.log(req.uri);
    if (!req.uri.anticsrf || !req.uri.name || !req.uri.email) {res.redirect('/create_account')}
    crypto.randomBytes(64, (err, buf) => {
      if (err) throw err;
      buf = buf.toString('base64');

      USERDATA[buf] = {
        last: 0,
        name: req.uri.name,
        completed: []
      }
      func.mailtoken(req.uri.email, buf);
      func.update_file(USERDATA);
      res.end('<html><a href="/submit" style="font-family:Courier">Continue', 200);
    });
  } else {
    res.sendFile(path + 'pages/create_account.html');
  }
});
/* OLD
app.post('/create_account', (req, res) => {
  if (req.url.includes('?')) {
    req.url.slice(16);
  }
  console.log(req.uri);
  res.end('OK', 200);
});*/

// submit page
app.get('/submit', (req, res) => res.sendFile(path + 'pages/submit.html'));
app.post('/submit', (req, res) => {
  let body = '';
  req.on('data', chunk => {
      body += chunk.toString(); // convert Buffer to string
  });
  req.on('end', () => {
      req.body = JSON.parse(body)
      if (req.body.token in USERDATA) {
        /*
        switch (req.body.chal) {
          case 0:
            res.end(USERDATA[req.body.token].completed, 200);

        }*/
        let user = USERDATA[req.body.token];
        if (req.body.chal === 0) { // asking for what has been solved
          res.end("Please select a challenge!")
        } else if (req.body.chal >= 1 && req.body.chal <= 18) { // submitting flag
          if (req.body.chal in user) { // already submitted and got correct
            res.end('You already completed that challenge.', 200);
          } else { //                                                flag not yet submitted correctly
            if (Date.now() - user.last >= SUBMIT_DELAY) { // not too fast
              if (req.body.flag === require('./secret.json')[req.body.chal]) { // if correct
                user.completed.push(req.body.chal);
                FLAG_DATA = func.recalculate_flag_var(USERDATA);
                func.update_file(USERDATA); // write the user data to file

                res.end(`Correct! (+${FLAG_DATA[req.body.chal].value}pt${(FLAG_DATA[req.body.chal].value==1?"s":"")})`)
              } else {
                user.last = Date.now()
                func.update_file(USERDATA); // store the user.last value
                res.end('Incorrect flag.', 200);
              }
            } else { // going way too fast
              res.end('Slow down!', 200);
            }
          }
        } else { // unknown challenge
          res.end('Invalid chal_id!', 200);
        }
      } else { // invalid token
        res.end('Invalid token', 403);
      }
  });
});

/** resources **/
// todo: this could probably be better done
// watermark
app.get('/watermark', (req, res) => res.sendFile(path + 'img/ctf_banner_large.png'));
// favicon
app.get('/favicon.ico', (req, res) => res.sendFile(path + 'img/favicon.ico'));
// user data
app.get('/userdata/*', (req, res) => res.end(JSON.stringify(USERDATA[req.url.slice(10)])||"{}", 200));
// flag_data
app.get('/flagdata', (req, res) => res.end(JSON.stringify(FLAG_DATA), 200));


/* CHALLENGE ROUTER */

app.get('/AB-0', (req, res) => { // set the cookie for this challenge
  res.cookie("ab0flag", "CT24bb[yumch0c0ch1p]");
  req.next();
});

// matches "s sSßSs sSßSss s"
let regex = /^(s\s\SS[^@|{\B"A-\M"S~s\s`S'$S-Z+.6}\t&\0^\ss*\\\-(?!0-9)#6%\w/]S){2,}?\S+\ss$/;
app.get('/AB-1/*', (req, res) => { // send the "success" page
  req.url = req.url.slice(6);
  if (regex.test(req.url)) { // test the acutal pass thingy
    res.sendFile(path + 'challenges/A/AB-1_flag.html');
  } else {
    res.end('Nope!', 403);
    //req.next();
  }
});

app.get('/AT-1/secret_file.txt', (req, res) => {
  res.sendfile(path + 'challenges/A/AT-1_flag.txt')
})



// other challenge pages (landing)
app.get(/^\/[ACS](B-[012]|T-[01]|N-0)$/, (req, res) => {
  chal_path = `${path}challenges${req.path.substring(0,2)}${req.path}.html`;
  if (fs.existsSync(chal_path)) {
    res.sendFile(chal_path)
  } else {
    req.next();
  }
});

/* FAILSAFE CATCH */
app.use((req, res) => {
  res.end('There\'s nothing here...', 404);
});

// listen
app.listen(port, () => {});

const credentials = {
	key: fs.readFileSync(`/etc/letsencrypt/live/${domain}/privkey.pem`, 'utf8'),
	cert: fs.readFileSync(`/etc/letsencrypt/live/${domain}/cert.pem`, 'utf8'),
	ca: fs.readFileSync(`/etc/letsencrypt/live/${domain}/chain.pem`, 'utf8')
};
const httpsServer;
const httpServer = require('http').createServer(app).
	listen(80, () => {
    httpsServer = require('https').createServer(credentials, app).
    	listen(443, () => {
        func.log(`\n\n########\nSTART at ${Date()}\nHTTP Server running on port 80\nHTTPS Server running on port 443\n########\n\n`)
    	});
	});
