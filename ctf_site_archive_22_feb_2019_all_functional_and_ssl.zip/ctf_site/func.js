const nodemailer = require('nodemailer');
const fs = require('fs');

exports.log = (text) => {
  fs.appendFileSync('./log.txt', text + '\n'); // todo: this is not great? because i should reuse file handle?
  console.log(text);
}

exports.recalculate_flag_var = (USERDATA) => {
  /* default */
  var flagdata = {
    1:  {name:"", solves:0, value:500, solved_by:[]},
    2:  {name:"", solves:0, value:500, solved_by:[]},
    3:  {name:"", solves:0, value:500, solved_by:[]},
    4:  {name:"", solves:0, value:500, solved_by:[]},
    5:  {name:"", solves:0, value:500, solved_by:[]},
    6:  {name:"", solves:0, value:500, solved_by:[]},
    7:  {name:"", solves:0, value:500, solved_by:[]},
    8:  {name:"", solves:0, value:500, solved_by:[]},
    9:  {name:"", solves:0, value:500, solved_by:[]},
    10: {name:"", solves:0, value:500, solved_by:[]},
    11: {name:"", solves:0, value:500, solved_by:[]},
    12: {name:"", solves:0, value:500, solved_by:[]},
    13: {name:"", solves:0, value:500, solved_by:[]},
    14: {name:"", solves:0, value:500, solved_by:[]},
    15: {name:"", solves:0, value:500, solved_by:[]},
    16: {name:"", solves:0, value:500, solved_by:[]},
    17: {name:"", solves:0, value:500, solved_by:[]},
    18: {name:"", solves:0, value:500, solved_by:[]},
    max: 0
  }
  // update all the specific chal thingies
  for (let idx in USERDATA) {
    let user = USERDATA[idx];
    for (let chal_id of user.completed) {
      let chal = flagdata[chal_id];
      chal.solved_by.push(user.name);
      chal.solves ++;
      chal.value = Math.round(chal.value/chal.solves);
    }
  }
  // update max value
  for (let k in flagdata) {
    if (k != "max") {
      flagdata.max += flagdata[k].value;
    }
  }
  return flagdata;
}

exports.mailtoken = (email, token) => {
  let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'blorangeblowfish@gmail.com',
      pass: 'super legit password 82'
    }
  });
  let mailOptions = {
    from: 'CT24bb Account Creation',
    to: email,
    subject: 'CT24bb Account Token',
    html: `You recently requested an account for the CT24bb event. To use your account, you will need this token:<br><span style="font-family:Courier;">${token}</span>.<br>(Not you? You can safely ignore this email)`
  };

  transporter.sendMail(mailOptions, (err, inf) => {
    if (err) {
      console.log(err);
    } else {
      console.log('Email sent: ' + inf.response);
    }
  });
}

exports.update_file = (data) => {
  let writeStream = fs.createWriteStream('./data.json');
  writeStream.write(JSON.stringify(data, (k,v)=>v, 2));
  writeStream.close();
}
